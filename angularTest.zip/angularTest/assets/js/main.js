function toggleFilterOn(){
    $("#tglFilter").click(function(){
        $("#applyFilter").slideUp();
      });
}

function toggleFilterOff(){

}

$(document).ready(function(){
    $("#tglFilter").click(function(){
        $("#applyFilter").slideDown();
        $("#tglFilter").hide();
      });
      $(".closeFilter").click(function(){
        $("#applyFilter").slideUp();
        $("#tglFilter").show();
      }); 
})